from django.shortcuts import render
from .models import Income, Expense, Investment

def dashboard(request):
    income = Income.objects.filter(user=request.user).aggregate(total=models.Sum('amount'))['total'] or 0
    expenses = Expense.objects.filter(user=request.user).aggregate(total=models.Sum('amount'))['total'] or 0
    investments = Investment.objects.filter(user=request.user).aggregate(total=models.Sum('amount'))['total'] or 0

    savings = income - (expenses + investments)
    goal = 600000  
    progress = (savings / goal) * 100 if goal > 0 else 0

    return render(request, 'dashboard.html', {
        'income': income, 'expenses': expenses, 'investments': investments,
        'savings': savings, 'goal': goal, 'progress': progress
    })
